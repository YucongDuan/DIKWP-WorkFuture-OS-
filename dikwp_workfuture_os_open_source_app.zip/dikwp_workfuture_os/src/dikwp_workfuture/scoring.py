from .models import TaskProfile, TaskScore, RoleProfile, RoleAssessment
from .text_utils import clamp
from .dikwp import register_task
from typing import Dict, List, Any
import statistics


def task_score(task: TaskProfile, adoption_context: Dict[str, float]) -> TaskScore:
    # Automatable work signals.
    ai_capability = (
        0.18 * task.routine_cognitive +
        0.10 * task.digital_input +
        0.14 * task.language_output +
        0.14 * task.data_processing +
        0.12 * task.standardized_decisions +
        0.16 * task.ai_tool_availability +
        0.12 * task.workflow_integrability +
        0.04 * task.routine_physical
    )
    # Human, physical and institutional anchors that resist clean replacement.
    human_anchor = (
        0.18 * task.safety_criticality +
        0.15 * task.legal_accountability +
        0.16 * task.physical_world_dependency +
        0.18 * task.interpersonal_trust +
        0.14 * task.tacit_context +
        0.10 * task.creative_novelty +
        0.09 * task.human_presence_requirement
    )
    economic_pressure = adoption_context.get("cost_pressure", 0.5)
    ai_maturity = adoption_context.get("ai_adoption_maturity", 0.5)
    regulation_friction = adoption_context.get("regulation_friction", 0.5)
    labor_shortage = adoption_context.get("labor_shortage", 0.3)
    org_training_capacity = adoption_context.get("training_capacity", 0.5)

    automation_exposure = clamp(ai_capability * (0.65 + 0.35 * ai_maturity) - 0.35 * human_anchor)
    augmentation_potential = clamp(ai_capability * (0.45 + 0.35 * human_anchor + 0.20 * org_training_capacity))
    replacement_pressure = clamp(
        automation_exposure * (0.45 + 0.25 * economic_pressure + 0.15 * ai_maturity + 0.15 * task.workflow_integrability)
        - 0.30 * human_anchor
        - 0.12 * regulation_friction
        - 0.10 * task.worker_learning_value
    )
    # Labor shortage pushes automation adoption, but can also support augmentation to keep scarce workers.
    replacement_pressure = clamp(replacement_pressure + 0.06 * labor_shortage * automation_exposure)
    reskilling_priority = clamp((replacement_pressure * task.frequency * task.business_value) + 0.35 * augmentation_potential)

    if task.safety_criticality >= 0.75 or task.legal_accountability >= 0.75:
        decision = "human_accountable_control_required"
    elif replacement_pressure >= 0.68:
        decision = "redesign_and_reskill_urgent"
    elif replacement_pressure >= 0.42 or augmentation_potential >= 0.6:
        decision = "augment_with_human_review"
    else:
        decision = "monitor_and_gradual_enablement"

    rationale = (
        f"AI capability signal={ai_capability:.2f}; human anchor={human_anchor:.2f}; "
        f"replacement pressure={replacement_pressure:.2f}; augmentation potential={augmentation_potential:.2f}."
    )
    return TaskScore(
        task_name=task.name,
        automation_exposure=round(automation_exposure, 4),
        augmentation_potential=round(augmentation_potential, 4),
        replacement_pressure=round(replacement_pressure, 4),
        human_anchor_score=round(clamp(human_anchor), 4),
        reskilling_priority=round(reskilling_priority, 4),
        decision=decision,
        rationale=rationale,
    )


def role_assessment(role: RoleProfile) -> RoleAssessment:
    scores = [task_score(t, role.adoption_context) for t in role.tasks]
    if not scores:
        raise ValueError("Role profile must include at least one task.")

    weights = [max(0.01, role.tasks[i].frequency * role.tasks[i].business_value) for i in range(len(role.tasks))]
    total_w = sum(weights)
    def wavg(attr):
        return sum(getattr(scores[i], attr) * weights[i] for i in range(len(scores))) / total_w

    replacement_risk = clamp(wavg("replacement_pressure"))
    augmentation = clamp(wavg("augmentation_potential"))
    human_anchor = clamp(wavg("human_anchor_score"))
    transition_urgency = clamp(0.62 * replacement_risk + 0.28 * augmentation + 0.10 * role.adoption_context.get("cost_pressure", 0.5))

    if replacement_risk >= 0.70:
        decision = "high_role_redesign_pressure"
    elif replacement_risk >= 0.45:
        decision = "medium_transition_planning_needed"
    elif augmentation >= 0.55:
        decision = "augmentation_first_strategy"
    else:
        decision = "low_short_term_replacement_pressure"

    reliability = "Provisional / Prototype" 
    if len(role.evidence_sources) >= 3 and len(role.tasks) >= 5:
        reliability = "Supported / Borrowed"
    elif len(role.evidence_sources) >= 1:
        reliability = "Provisional / Borrowed"

    evidence_ledger = []
    for src in role.evidence_sources:
        evidence_ledger.append({
            "source": src.get("source", "unknown"),
            "type": src.get("type", "unspecified"),
            "supports": src.get("supports", "role/task context"),
            "does_not_support": "individual employment decision or deterministic job-loss prediction",
            "reliability": src.get("reliability", "Borrowed / Provisional"),
        })
    if not evidence_ledger:
        evidence_ledger.append({
            "source": "user_supplied_role_profile_only",
            "type": "local_input",
            "supports": "prototype role assessment",
            "does_not_support": "labor-market prediction without external data",
            "reliability": "Provisional",
        })

    residuals = [
        "Forecast depends on adoption speed, regulation, local wages, workflow redesign and organizational incentives.",
        "Occupation-level exposure does not equal job loss; tasks may be augmented, redistributed, or redesigned.",
        "Worker-level outcomes require consent, consultation, anti-discrimination review and human governance.",
        "The model is heuristic and should be calibrated against local labor data before policy use.",
    ]
    kill_conditions = [
        "Used to rank or terminate individual workers.",
        "Task inventory is inaccurate or excludes tacit, safety, interpersonal or legal-accountability work.",
        "External labor-market sources contradict the assumed adoption context.",
        "Protected-class or demographic variables are used for replacement scoring.",
        "Human review and worker transition planning are removed.",
    ]
    recovery_actions = [
        "Rebuild the role as a task portfolio rather than an individual-worker score.",
        "Run worker consultation and impact review before any organizational decision.",
        "Convert high-risk tasks into human-accountable augmentation pilots.",
        "Create reskilling, redeployment and apprenticeship pathways before headcount actions.",
        "Recalibrate with O*NET, BLS/OEWS, internal workflow telemetry and local market data.",
    ]

    return RoleAssessment(
        role_title=role.role_title,
        industry=role.industry,
        region=role.region,
        ai_replacement_risk=round(replacement_risk, 4),
        ai_augmentation_opportunity=round(augmentation, 4),
        transition_urgency=round(transition_urgency, 4),
        human_anchor_index=round(human_anchor, 4),
        forecast_reliability=reliability,
        decision=decision,
        task_scores=scores,
        evidence_ledger=evidence_ledger,
        residuals=residuals,
        kill_conditions=kill_conditions,
        recovery_actions=recovery_actions,
    )


def forecast_timeline(assessment: RoleAssessment) -> List[Dict[str, float]]:
    base = assessment.ai_replacement_risk
    aug = assessment.ai_augmentation_opportunity
    h = assessment.human_anchor_index
    rows = []
    for months, multiplier in [(12, 0.55), (24, 0.75), (36, 0.95), (60, 1.18)]:
        replacement = clamp(base * multiplier - 0.08 * h)
        augmentation = clamp(aug * (0.60 + 0.12 * months / 12.0))
        redesign = clamp(0.45 * replacement + 0.55 * augmentation)
        rows.append({
            "horizon_months": months,
            "replacement_pressure_index": round(replacement, 4),
            "augmentation_opportunity_index": round(augmentation, 4),
            "role_redesign_need_index": round(redesign, 4),
        })
    return rows
