# Governance Boundary

Employment and worker-management AI systems are high-risk in many regulatory contexts. WorkFuture OS is designed to avoid automated individual employment decisions.

Required safeguards:

- task-level only;
- no protected-class variables;
- human review;
- worker consultation;
- transition and reskilling plan before structural change;
- documentation of evidence and uncertainty;
- legal and labor review for organizational use.
