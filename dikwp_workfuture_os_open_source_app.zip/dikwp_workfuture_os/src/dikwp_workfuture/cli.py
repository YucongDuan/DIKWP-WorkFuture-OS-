import argparse, json
from .analyzer import analyze_role_file, analyze_batch_file
from .static_audit import write_audit


def main(argv=None):
    parser = argparse.ArgumentParser(prog="workfuture", description="DIKWP task-level AI occupational replacement assessment.")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("analyze")
    p1.add_argument("role_profile")
    p1.add_argument("--out", default="outputs/demo")
    p2 = sub.add_parser("batch")
    p2.add_argument("portfolio_profile")
    p2.add_argument("--out", default="outputs/batch")
    p3 = sub.add_parser("static-audit")
    p3.add_argument("src")
    p3.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args(argv)
    if args.cmd == "analyze":
        report = analyze_role_file(args.role_profile, args.out)
        print(json.dumps({"decision": report["decision"], "replacement_risk": report["ai_replacement_risk"], "augmentation_opportunity": report["ai_augmentation_opportunity"]}, ensure_ascii=False, indent=2))
    elif args.cmd == "batch":
        report = analyze_batch_file(args.portfolio_profile, args.out)
        print(json.dumps({"portfolio_role_count": report["portfolio_role_count"]}, ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        report = write_audit(args.src, args.out)
        print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
