import re
from typing import List

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        v = float(x)
    except Exception:
        v = 0.0
    return max(lo, min(hi, v))

def norm_text(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())

def keyword_score(text: str, keywords: List[str]) -> float:
    t = (text or "").lower()
    if not keywords:
        return 0.0
    hits = sum(1 for k in keywords if k.lower() in t)
    return min(1.0, hits / max(1, min(5, len(keywords))))
