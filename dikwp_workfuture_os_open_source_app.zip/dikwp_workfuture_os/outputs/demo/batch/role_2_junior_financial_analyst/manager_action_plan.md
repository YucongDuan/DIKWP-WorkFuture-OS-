# Manager Action Plan: Junior Financial Analyst

## What to do first

- Discuss the task inventory with workers before making structural decisions.
- Prioritize augmentation pilots where human accountability remains clear.
- Do not remove entry-level learning tasks without replacing the apprenticeship pathway.
- Track productivity, quality, worker stress and customer outcomes together.

## Governance gates

- Kill condition: Used to rank or terminate individual workers.
- Kill condition: Task inventory is inaccurate or excludes tacit, safety, interpersonal or legal-accountability work.
- Kill condition: External labor-market sources contradict the assumed adoption context.
- Kill condition: Protected-class or demographic variables are used for replacement scoring.
- Kill condition: Human review and worker transition planning are removed.

## Recovery actions

- Rebuild the role as a task portfolio rather than an individual-worker score.
- Run worker consultation and impact review before any organizational decision.
- Convert high-risk tasks into human-accountable augmentation pilots.
- Create reskilling, redeployment and apprenticeship pathways before headcount actions.
- Recalibrate with O*NET, BLS/OEWS, internal workflow telemetry and local market data.