# Integration Guide

Recommended future integrations:

- O*NET occupation and task descriptors;
- BLS/OEWS employment and wage tables;
- local job-posting skill demand feeds;
- HRIS role inventory, with privacy controls;
- learning management systems;
- ProofLedger OS for evidence checking;
- AgentTrace OS for workflow telemetry;
- SemanticEnergy OS for cost and productivity impact.

Do not integrate employee protected characteristics into replacement scoring.
