from typing import Dict, Any, List

def register_task(task: Dict[str, Any], evidence_sources: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "D": {
            "task_name": task.get("name"),
            "description": task.get("description"),
            "observed_inputs": ["role_profile_json", "task_feature_scores"],
            "evidence_source_count": len(evidence_sources),
        },
        "I": {
            "routine_cognitive": task.get("routine_cognitive"),
            "digital_input": task.get("digital_input"),
            "language_output": task.get("language_output"),
            "data_processing": task.get("data_processing"),
            "physical_world_dependency": task.get("physical_world_dependency"),
            "interpersonal_trust": task.get("interpersonal_trust"),
        },
        "K": {
            "model": "task-level AI exposure = automatable work signal minus human/physical/accountability anchors",
            "external_reliability": "Borrowed when connected to O*NET, BLS, ILO, WEF, OECD or local labor-market sources",
        },
        "W": {
            "worker_dignity": "Do not convert task exposure into individual layoff decision.",
            "fairness": "Check differential impact before any workforce action.",
            "safety": "Safety-critical tasks require human accountable control.",
        },
        "P": {
            "purpose": "role redesign, reskilling and transition planning",
            "not_purpose": "automated employment decision, firing, ranking individual workers",
        },
        "R": {
            "confidence": "heuristic_prototype",
            "kill": "Invalid if role/task data are inaccurate, outdated, or used for individual employment decisions.",
        },
    }
