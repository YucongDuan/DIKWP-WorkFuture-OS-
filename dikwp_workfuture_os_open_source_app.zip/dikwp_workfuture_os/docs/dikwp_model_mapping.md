# DIKWP Model Mapping

## D / Data
Role description, task list, frequency, business value, external evidence, workflow samples.

## I / Information
Task features: routine, digital input, language output, data processing, standardization, AI tool availability, physical dependency, trust, safety and legal accountability.

## K / Knowledge
Task-based AI exposure modeling, augmentation vs automation distinction, O*NET-style task decomposition, labor-market priors.

## W / Wisdom
Worker dignity, anti-discrimination, apprenticeship preservation, human accountability, transition fairness.

## P / Purpose
Preserve livelihood, improve productivity, reduce drudgery, redesign work responsibly, support reskilling.

## R / Reliability
Forecast reliability, evidence ledger, residuals, kill conditions, recovery plan.
