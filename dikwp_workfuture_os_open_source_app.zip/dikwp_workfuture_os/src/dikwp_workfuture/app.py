try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from pathlib import Path
import json, tempfile
from .analyzer import analyze_role_file


def main():
    if st is None:
        raise RuntimeError("Install streamlit with: pip install -e .[app]")
    st.title("DIKWP WorkFuture OS")
    st.caption("Task-level AI occupational replacement and augmentation assessment. Not an employment-decision tool.")
    uploaded = st.file_uploader("Upload role profile JSON", type=["json"])
    if uploaded:
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / "role.json"
            src.write_bytes(uploaded.read())
            out = Path(d) / "out"
            report = analyze_role_file(str(src), str(out))
            st.metric("AI replacement risk", report["ai_replacement_risk"])
            st.metric("Augmentation opportunity", report["ai_augmentation_opportunity"])
            st.write(report["decision"])
            st.json(report)

if __name__ == "__main__":
    main()
