from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

@dataclass
class TaskProfile:
    name: str
    description: str
    frequency: float = 0.5
    business_value: float = 0.5
    routine_cognitive: float = 0.5
    routine_physical: float = 0.0
    digital_input: float = 0.5
    language_output: float = 0.5
    data_processing: float = 0.5
    standardized_decisions: float = 0.5
    ai_tool_availability: float = 0.5
    workflow_integrability: float = 0.5
    error_cost: float = 0.5
    safety_criticality: float = 0.0
    legal_accountability: float = 0.2
    physical_world_dependency: float = 0.0
    interpersonal_trust: float = 0.2
    tacit_context: float = 0.3
    creative_novelty: float = 0.2
    human_presence_requirement: float = 0.2
    worker_learning_value: float = 0.3

@dataclass
class RoleProfile:
    role_title: str
    industry: str = "unspecified"
    region: str = "unspecified"
    role_purpose: str = ""
    employment_scale: int = 1
    adoption_context: Dict[str, float] = field(default_factory=dict)
    tasks: List[TaskProfile] = field(default_factory=list)
    evidence_sources: List[Dict[str, Any]] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)

@dataclass
class TaskScore:
    task_name: str
    automation_exposure: float
    augmentation_potential: float
    replacement_pressure: float
    human_anchor_score: float
    reskilling_priority: float
    decision: str
    rationale: str

@dataclass
class RoleAssessment:
    role_title: str
    industry: str
    region: str
    ai_replacement_risk: float
    ai_augmentation_opportunity: float
    transition_urgency: float
    human_anchor_index: float
    forecast_reliability: str
    decision: str
    task_scores: List[TaskScore]
    evidence_ledger: List[Dict[str, Any]]
    residuals: List[str]
    kill_conditions: List[str]
    recovery_actions: List[str]


def to_dict(obj):
    return asdict(obj)
