# Worker Reskilling Plan: Customer Support Specialist

## Core judgment

Role-level AI replacement risk: **0.25**. Augmentation opportunity: **0.44**. Decision: **low_short_term_replacement_pressure**.

This is not an individual worker score. It is a task-level transition planning artifact.

## Priority task transitions

- **Draft routine support replies**: replacement pressure 0.41, augmentation 0.50, decision `monitor_and_gradual_enablement`.
- **Summarize tickets and update CRM fields**: replacement pressure 0.46, augmentation 0.48, decision `augment_with_human_review`.
- **Diagnose complex account configuration issues**: replacement pressure 0.09, augmentation 0.41, decision `monitor_and_gradual_enablement`.
- **Create customer education content**: replacement pressure 0.15, augmentation 0.40, decision `monitor_and_gradual_enablement`.
- **Handle angry customer escalation**: replacement pressure 0.00, augmentation 0.33, decision `monitor_and_gradual_enablement`.

## Skill bridges

- **AI workflow literacy**: Operate and verify AI tools rather than compete with them as black boxes.
- **Evidence and citation checking**: Many AI outputs require source validation before use.
- **Exception handling and escalation**: Human value rises around ambiguity, accountability, trust and edge cases.
- **Domain judgment and customer/context empathy**: Tacit context and trust remain human anchors.
- **Process redesign**: Role resilience improves when workers shape AI-enabled workflows.

## 30 / 90 / 180 day path

### 30 day actions
- Create a task inventory and mark tasks that are repetitive, digital and evidence-checkable.
- Pilot AI assistance on low-risk tasks with human verification.
- Document what the AI gets wrong and what human judgment adds.
### 90 day actions
- Convert high-frequency AI-amenable tasks into supervised workflows.
- Build role-specific prompt, proof and escalation templates.
- Start cross-training for tasks with rising replacement pressure.
### 180 day actions
- Redesign the role around accountable review, exception management, relationship work and domain expertise.
- Create internal mobility paths before any headcount reduction is considered.
- Measure productivity gains and worker outcomes together.

## Boundary

Do not use this plan to terminate or rank individual workers. Use it for learning, role redesign and worker-supported transition planning.