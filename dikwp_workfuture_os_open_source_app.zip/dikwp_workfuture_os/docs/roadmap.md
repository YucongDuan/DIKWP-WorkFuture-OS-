# Roadmap

## v0.2
- O*NET connector
- BLS/OEWS connector
- role-template library
- improved skill graph

## v0.3
- job posting skill-demand trend connector
- multilingual occupation profiles
- team portfolio dashboard

## v0.4
- worker consent and consultation workflow
- transition-equity metrics
- integration with MemoryLedger and ProofLedger

## v1.0
- calibrated exposure benchmark
- enterprise deployment package
- model cards and compliance artifacts
