Contributions are welcome. Please preserve worker-rights, evidence-ledger and non-discrimination boundaries.
