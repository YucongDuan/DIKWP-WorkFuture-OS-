from pathlib import Path
import json, tempfile
from dikwp_workfuture.analyzer import analyze_role_file, analyze_batch_file
from dikwp_workfuture.static_audit import audit_tree

ROOT = Path(__file__).resolve().parents[1]

def test_demo_role_runs():
    with tempfile.TemporaryDirectory() as d:
        report = analyze_role_file(str(ROOT / "examples" / "sample_role_profile.json"), d)
        assert report["ai_replacement_risk"] >= 0
        assert report["ai_augmentation_opportunity"] >= 0
        assert Path(d, "task_exposure_matrix.csv").exists()


def test_batch_runs():
    with tempfile.TemporaryDirectory() as d:
        report = analyze_batch_file(str(ROOT / "examples" / "sample_workforce_portfolio.json"), d)
        assert report["portfolio_role_count"] == 2
        assert Path(d, "workforce_portfolio_summary.csv").exists()


def test_static_audit_passes():
    report = audit_tree(str(ROOT / "src"))
    assert report["pass"] is True
