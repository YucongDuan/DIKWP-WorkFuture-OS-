# Release Draft: DIKWP WorkFuture OS v0.1.0

We are releasing DIKWP WorkFuture OS, an open-source role/task-level AI occupational replacement and augmentation assessment toolkit.

Highlights:
- task exposure matrix;
- replacement pressure forecast;
- augmentation opportunity map;
- worker reskilling plan;
- manager action plan;
- governance boundary;
- offline-first CLI.
