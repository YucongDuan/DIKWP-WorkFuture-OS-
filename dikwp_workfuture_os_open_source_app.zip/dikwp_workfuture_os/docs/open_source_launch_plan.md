# Open Source Launch Plan

1. Publish GitHub repository with README, demo, docs and NOTICE.
2. Pin the project under the DIKWP ecosystem.
3. Release a Chinese article explaining "AI replacement forecast should be task-level, not worker-labeling".
4. Invite HR, education, labor policy and AI governance communities.
5. Build public demo using O*NET examples.
6. Add benchmark dataset and evaluation challenges.
7. Offer enterprise deployment and training services.
