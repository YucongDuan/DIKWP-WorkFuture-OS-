# Architecture

The system has four layers:

1. **Input layer**: role profiles, task lists, local context and evidence sources.
2. **DIKWP compiler**: transforms tasks into C=(D,I,K,W,P,R).
3. **Scoring layer**: automation exposure, augmentation opportunity, replacement pressure, human anchor, reskilling priority.
4. **Governance output layer**: worker reskilling plan, manager action plan, forecast timeline and kill/recovery boundary.

The design is deliberately offline-first. No network calls are needed for the prototype. Future connectors may ingest O*NET, BLS/OEWS, ILO exposure indexes, OECD skill demand reports and internal workflow telemetry.
