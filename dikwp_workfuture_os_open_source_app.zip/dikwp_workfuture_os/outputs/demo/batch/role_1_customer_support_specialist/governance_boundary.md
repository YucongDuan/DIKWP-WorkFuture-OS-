# Governance Boundary

DIKWP WorkFuture OS supports task-level planning only.

Allowed uses:
- task exposure assessment;
- role redesign;
- reskilling prioritization;
- workforce transition planning;
- AI augmentation pilot scoping;
- evidence-led discussion with workers and managers.

Disallowed uses:
- automated hiring, firing, promotion, discipline or compensation decisions;
- ranking individual workers;
- using protected class, age, gender, disability, family status or union status as replacement variables;
- hiding AI adoption plans from affected workers;
- replacing human consultation, labor law, collective bargaining or professional HR/legal review;
- claiming deterministic job-loss predictions.