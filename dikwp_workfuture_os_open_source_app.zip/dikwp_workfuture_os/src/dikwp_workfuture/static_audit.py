from pathlib import Path
import ast, json

FORBIDDEN_IMPORTS = {"socket", "subprocess", "requests", "urllib", "http", "ftplib", "paramiko", "shutil"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__", "open"}  # open is permitted only if explicitly audited; we flag then suppress local file writers manually.


def audit_tree(root_path: str) -> dict:
    root = Path(root_path)
    findings = []
    for path in root.rglob("*.py"):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception as e:
            findings.append({"file": str(path), "type": "parse_error", "detail": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split('.')[0]
                    if top in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                mod = (node.module or "").split('.')[0]
                if mod in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(path), "type": "forbidden_import", "detail": node.module})
            elif isinstance(node, ast.Call):
                name = ""
                if isinstance(node.func, ast.Name):
                    name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    name = node.func.attr
                if name in {"eval", "exec", "compile", "__import__"}:
                    findings.append({"file": str(path), "type": "forbidden_call", "detail": name})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, or host mutation helpers. Local file writes through pathlib are allowed for reports.",
    }


def write_audit(root_path: str, out_path: str) -> dict:
    report = audit_tree(root_path)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
