import json, csv
from pathlib import Path
from typing import Dict, Any, List
from .models import TaskProfile, RoleProfile, to_dict
from .scoring import role_assessment, forecast_timeline


def load_role(path: str) -> RoleProfile:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    tasks = [TaskProfile(**t) for t in data.get("tasks", [])]
    return RoleProfile(
        role_title=data.get("role_title", "Unknown Role"),
        industry=data.get("industry", "unspecified"),
        region=data.get("region", "unspecified"),
        role_purpose=data.get("role_purpose", ""),
        employment_scale=int(data.get("employment_scale", 1)),
        adoption_context=data.get("adoption_context", {}),
        tasks=tasks,
        evidence_sources=data.get("evidence_sources", []),
        constraints=data.get("constraints", []),
    )


def write_csv(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def build_skill_transition_plan(role: RoleProfile, assessment) -> Dict[str, Any]:
    high = [s for s in assessment.task_scores if s.replacement_pressure >= 0.45 or s.augmentation_potential >= 0.55]
    plan = {
        "role_title": role.role_title,
        "transition_principle": "Move from task replacement fear to task redesign, human-accountable augmentation and skill mobility.",
        "priority_tasks": [s.task_name for s in sorted(high, key=lambda x: x.reskilling_priority, reverse=True)],
        "skill_bridges": [
            {"skill": "AI workflow literacy", "why": "Operate and verify AI tools rather than compete with them as black boxes."},
            {"skill": "Evidence and citation checking", "why": "Many AI outputs require source validation before use."},
            {"skill": "Exception handling and escalation", "why": "Human value rises around ambiguity, accountability, trust and edge cases."},
            {"skill": "Domain judgment and customer/context empathy", "why": "Tacit context and trust remain human anchors."},
            {"skill": "Process redesign", "why": "Role resilience improves when workers shape AI-enabled workflows."},
        ],
        "30_day_actions": [
            "Create a task inventory and mark tasks that are repetitive, digital and evidence-checkable.",
            "Pilot AI assistance on low-risk tasks with human verification.",
            "Document what the AI gets wrong and what human judgment adds.",
        ],
        "90_day_actions": [
            "Convert high-frequency AI-amenable tasks into supervised workflows.",
            "Build role-specific prompt, proof and escalation templates.",
            "Start cross-training for tasks with rising replacement pressure.",
        ],
        "180_day_actions": [
            "Redesign the role around accountable review, exception management, relationship work and domain expertise.",
            "Create internal mobility paths before any headcount reduction is considered.",
            "Measure productivity gains and worker outcomes together.",
        ],
    }
    return plan


def markdown_worker_plan(role: RoleProfile, assessment, plan: Dict[str, Any]) -> str:
    lines = []
    lines.append(f"# Worker Reskilling Plan: {role.role_title}\n")
    lines.append("## Core judgment\n")
    lines.append(f"Role-level AI replacement risk: **{assessment.ai_replacement_risk:.2f}**. Augmentation opportunity: **{assessment.ai_augmentation_opportunity:.2f}**. Decision: **{assessment.decision}**.\n")
    lines.append("This is not an individual worker score. It is a task-level transition planning artifact.\n")
    lines.append("## Priority task transitions\n")
    for s in sorted(assessment.task_scores, key=lambda x: x.reskilling_priority, reverse=True):
        lines.append(f"- **{s.task_name}**: replacement pressure {s.replacement_pressure:.2f}, augmentation {s.augmentation_potential:.2f}, decision `{s.decision}`.")
    lines.append("\n## Skill bridges\n")
    for item in plan["skill_bridges"]:
        lines.append(f"- **{item['skill']}**: {item['why']}")
    lines.append("\n## 30 / 90 / 180 day path\n")
    for key in ["30_day_actions", "90_day_actions", "180_day_actions"]:
        lines.append(f"### {key.replace('_', ' ')}")
        for action in plan[key]:
            lines.append(f"- {action}")
    lines.append("\n## Boundary\n")
    lines.append("Do not use this plan to terminate or rank individual workers. Use it for learning, role redesign and worker-supported transition planning.")
    return "\n".join(lines)


def manager_action_plan(role: RoleProfile, assessment) -> str:
    lines = [f"# Manager Action Plan: {role.role_title}\n"]
    lines.append("## What to do first\n")
    lines.extend([
        "- Discuss the task inventory with workers before making structural decisions.",
        "- Prioritize augmentation pilots where human accountability remains clear.",
        "- Do not remove entry-level learning tasks without replacing the apprenticeship pathway.",
        "- Track productivity, quality, worker stress and customer outcomes together.",
    ])
    lines.append("\n## Governance gates\n")
    for kc in assessment.kill_conditions:
        lines.append(f"- Kill condition: {kc}")
    lines.append("\n## Recovery actions\n")
    for a in assessment.recovery_actions:
        lines.append(f"- {a}")
    return "\n".join(lines)


def analyze_role_file(path: str, out_dir: str) -> Dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    role = load_role(path)
    assessment = role_assessment(role)
    timeline = forecast_timeline(assessment)
    plan = build_skill_transition_plan(role, assessment)

    report = to_dict(assessment)
    report["forecast_timeline"] = timeline
    report["role_purpose"] = role.role_purpose
    report["constraints"] = role.constraints
    report["semantic_registry"] = {
        "C": "AI occupational replacement assessment",
        "D": "role profile, task inventory, evidence sources",
        "I": "task exposure, adoption context, human anchors, replacement pressure",
        "K": "task-based AI exposure model with reskilling transition logic",
        "W": "worker dignity, fairness, non-discrimination, human accountability",
        "P": "transition planning, not automated employment decision",
        "R": assessment.forecast_reliability,
    }

    (out / "workfuture_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    task_rows = [to_dict(s) for s in assessment.task_scores]
    write_csv(out / "task_exposure_matrix.csv", task_rows)
    write_csv(out / "role_forecast_timeline.csv", timeline)
    (out / "skill_transition_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "worker_reskilling_plan.md").write_text(markdown_worker_plan(role, assessment, plan), encoding="utf-8")
    (out / "manager_action_plan.md").write_text(manager_action_plan(role, assessment), encoding="utf-8")
    (out / "governance_boundary.md").write_text(GOVERNANCE_BOUNDARY, encoding="utf-8")
    return report


def analyze_batch_file(path: str, out_dir: str) -> Dict[str, Any]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    roles = data.get("roles", [])
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for idx, role_data in enumerate(roles):
        temp = out / f"role_{idx+1}.json"
        temp.write_text(json.dumps(role_data, ensure_ascii=False, indent=2), encoding="utf-8")
        rdir = out / f"role_{idx+1}_{role_data.get('role_title','role').lower().replace(' ','_')}"
        report = analyze_role_file(str(temp), str(rdir))
        rows.append({
            "role_title": report["role_title"],
            "industry": report["industry"],
            "region": report["region"],
            "replacement_risk": report["ai_replacement_risk"],
            "augmentation_opportunity": report["ai_augmentation_opportunity"],
            "transition_urgency": report["transition_urgency"],
            "human_anchor_index": report["human_anchor_index"],
            "decision": report["decision"],
        })
        temp.unlink(missing_ok=True)
    write_csv(out / "workforce_portfolio_summary.csv", rows)
    portfolio = {
        "system": "DIKWP WorkFuture OS",
        "portfolio_role_count": len(rows),
        "summary_rows": rows,
        "portfolio_boundary": "Use for workforce planning and reskilling, not individual employment decisions.",
    }
    (out / "workforce_portfolio_report.json").write_text(json.dumps(portfolio, ensure_ascii=False, indent=2), encoding="utf-8")
    return portfolio

GOVERNANCE_BOUNDARY = """
# Governance Boundary

DIKWP WorkFuture OS supports task-level planning only.

Allowed uses:
- task exposure assessment;
- role redesign;
- reskilling prioritization;
- workforce transition planning;
- AI augmentation pilot scoping;
- evidence-led discussion with workers and managers.

Disallowed uses:
- automated hiring, firing, promotion, discipline or compensation decisions;
- ranking individual workers;
- using protected class, age, gender, disability, family status or union status as replacement variables;
- hiding AI adoption plans from affected workers;
- replacing human consultation, labor law, collective bargaining or professional HR/legal review;
- claiming deterministic job-loss predictions.
""".strip()
