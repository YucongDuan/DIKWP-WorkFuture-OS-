Use this project respectfully. Do not use it to target, harass, discriminate against or mislead workers.
